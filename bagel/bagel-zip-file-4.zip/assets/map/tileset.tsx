<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="simple" tilewidth="16" tileheight="16" tilecount="4" columns="2">
 <image source="simple.png" width="32" height="32"/>
 <tile id="2">
  <properties>
   <property name="blocked" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
